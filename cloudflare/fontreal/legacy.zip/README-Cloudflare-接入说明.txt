FontReal V5 Cloudflare Pages 接入包（请整体上传 ZIP）

本文件用于更新现有的 fontreal.pages.dev 项目，不是 Render 后端源码。

前提：先将“FontReal-V5-完整版服务端-部署源码.zip”中的完整 Next.js 工程部署到 Render，并能直接打开其 HTTPS 地址。

1. Cloudflare → Workers 和 Pages → fontreal → Settings → Environment variables and secrets。
2. 设置生产环境变量 FONTREAL_BACKEND_ORIGIN=https://你的Render实际子域名.onrender.com（仅作为格式示例，请填写真实值，不能填写 fontreal.pages.dev）
3. 回到 Deployments → Create deployment → 上传本 ZIP；选择 production（生产部署）。
4. 访问 https://fontreal.pages.dev 和 https://fontreal.pages.dev/__fontreal_mode ，后一个返回 mode:full-v5-proxy 表示变量已生效（不意味着 Render 服务一定正常）。

未配置变量时，旧静态编辑器继续可访问。代理转发用户请求到后端；AI 密钥只在 Render 环境变量中存储。Render 免费服务可能休眠，并不适合对外稳定生产使用。
