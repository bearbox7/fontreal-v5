/**
 * FontReal V5: Cloudflare Pages Advanced Mode worker.
 * Set FONTREAL_BACKEND_ORIGIN under Cloudflare Pages production environment.
 * Without it, the previous static editor is served through env.ASSETS.
 */
function apiError(message, status=503){
  return Response.json({ok:false,error:message},{status,headers:{'Cache-Control':'no-store'}});
}
function isNavigation(request){
  return (request.method==='GET'||request.method==='HEAD') &&
    (request.headers.get('accept')||'').includes('text/html');
}
export default {
  async fetch(request, env, ctx) {
    const raw = String(env.FONTREAL_BACKEND_ORIGIN||'').trim();
    if (!raw) return env.ASSETS.fetch(request);
    let backend;
    try {
      backend=new URL(raw);
      if(backend.protocol!=='https:' || backend.username || backend.password ||
        backend.pathname!=='/' || backend.search || backend.hash ||
        backend.hostname==='fontreal.pages.dev' ||
        raw.replace(/\/$/,'')!==backend.origin) throw Error('bad origin');
    } catch {
      return apiError('FontReal 后端地址配置错误：请填写 Render 服务的 HTTPS 根域名，不要填 Pages 域名。');
    }
    const publicUrl = new URL(request.url);
    if (publicUrl.pathname==='/__fontreal_mode') {
      return Response.json({mode:'full-v5-proxy',backendConfigured:true},{headers:{'Cache-Control':'no-store'}});
    }
    const target = new URL(publicUrl.pathname+publicUrl.search,backend);
    const upstreamReq = new Request(target.toString(),request);
    // Original Next endpoints verify same-origin POST requests. The proxied
    // browser request comes from fontreal.pages.dev, so rewrite only if the
    // request's Origin/Referer really belongs to our public Pages hostname.
    const origin=request.headers.get('Origin');
    if(origin && origin===publicUrl.origin) upstreamReq.headers.set('Origin',backend.origin);
    const referer=request.headers.get('Referer');
    if(referer && referer.startsWith(publicUrl.origin+'/')) {
      upstreamReq.headers.set('Referer',backend.origin+referer.slice(publicUrl.origin.length));
    }
    upstreamReq.headers.delete('Host');
    try {
      const upstream = await fetch(upstreamReq,{redirect:'manual'});
      const headers = new Headers(upstream.headers);
      const loc=headers.get('Location');
      if(loc){
        try{const redirect=new URL(loc,backend.origin);
          if(redirect.origin===backend.origin)headers.set('Location',publicUrl.origin+redirect.pathname+redirect.search+redirect.hash);
        }catch{}
      }
      headers.set('X-FontReal-Backend','V5');
      headers.set('Vary','Accept-Encoding');
      return new Response(upstream.body,{status:upstream.status,statusText:upstream.statusText,headers});
    } catch (error) {
      if(isNavigation(request)){
        // Best effort: keep current static editor accessible during host outages.
        const offline=await env.ASSETS.fetch(request);
        if(offline.ok) return offline;
      }
      return apiError('FontReal V5 服务暂时无法连接；请检查 Render 实例状态，免费实例休眠后可能需要一段时间唤醒。');
    }
  }
};
